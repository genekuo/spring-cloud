#!/bin/sh
sudo killall java
exit 0